export var single = [
    {
      "name": "New Requests",
      "value": 12
    },
    {
      "name": "In Progress",
      "value": 30
    },
    {
      "name": "Under Review",
      "value": 20
    },

  ];