export var cities = [
    {
      "name": "Berlin",
      "value": 12
    },
    {
      "name": "Paris",
      "value": 30
    },
    {
      "name": "Bucharest",
      "value": 20
    }

  ];